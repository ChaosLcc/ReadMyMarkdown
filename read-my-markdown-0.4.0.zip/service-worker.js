chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason !== 'install') return;
  const welcome = new URL(chrome.runtime.getURL('index.html'));
  welcome.searchParams.set('welcome', 'install');
  chrome.tabs.create({ url: welcome.href });
});

chrome.action.onClicked.addListener(() => {
  const url = chrome.runtime.getURL('index.html');
  chrome.tabs.create({ url });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'open-file-access-settings') {
    let source;
    try { source = new URL(sender.url); } catch {
      sendResponse({ ok: false });
      return;
    }
    const reader = new URL(chrome.runtime.getURL('index.html'));
    if (sender.id !== chrome.runtime.id || source.protocol !== reader.protocol
      || source.host !== reader.host || source.pathname !== reader.pathname) {
      sendResponse({ ok: false });
      return;
    }
    const browserScheme = /Edg\//.test(navigator.userAgent) ? 'edge' : 'chrome';
    chrome.tabs.create({ url: `${browserScheme}://extensions/?id=${chrome.runtime.id}` }).then(
      () => sendResponse({ ok: true }),
      () => sendResponse({ ok: false })
    );
    return true;
  }
  if (message?.type !== 'open-local-markdown') return;
  // Trust Chrome's sender metadata rather than a page-supplied file URL.
  let source;
  try { source = new URL(sender.url); } catch { return; }
  if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id)
    || source.protocol !== 'file:' || !/\.(md|markdown|mdown|mkdn|mkd)$/i.test(source.pathname)) return;
  const reader = new URL(chrome.runtime.getURL('index.html'));
  reader.searchParams.set('file', source.href);
  chrome.tabs.update(sender.tab.id, { url: reader.href }).then(
    () => sendResponse({ ok: true }),
    () => sendResponse({ ok: false })
  );
  return true;
});
