import{c as e,s as r}from"./flowDiagram-HODETNUW-BG2K3Jyg.js";import{_ as a}from"./main-D2O7aV9h.js";import"./chunk-5VM5RSS4-Cuq_89Cr.js";import"./chunk-XXDRQBXY-3tC3jWhm.js";import"./chunk-POPQ4Y6H-CZtnzyyL.js";import"./chunk-F27PBJKO-CbHA5kTX.js";import"./channel-IntzGQ2J.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
