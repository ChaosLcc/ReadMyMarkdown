import{ai as o,aj as n}from"./main-D2O7aV9h.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
